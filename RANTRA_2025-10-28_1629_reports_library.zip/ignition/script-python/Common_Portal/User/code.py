def Plant_access(Business_ID, userRoles):
	plantDataset = system.tag.read("[default]Common_Portal/User_Managmet/Plant").value
	selectedBusinessID = Business_ID
	matchedPlantIDs = []
	matchedPlantNames = []
	filteredRows = []
	dropdownList = []
	dropdownList_DS = []
	if plantDataset is not None and plantDataset.rowCount > 0:
		for rowIndex in range(plantDataset.rowCount):
			businessID = plantDataset.getValueAt(rowIndex, "Business_ID")
			plantID = plantDataset.getValueAt(rowIndex, "Plant_ID")
			plantName = plantDataset.getValueAt(rowIndex, "Plant_Name")
			if businessID != selectedBusinessID:
				continue
			isAdmin = "HO" in userRoles or "RDC Admin" in userRoles
			isRoleMatched = str(plantID) in userRoles or plantName in userRoles
			if (isAdmin and plantName.strip().upper() != "HO") or (not isAdmin and isRoleMatched):
				matchedPlantIDs.append(plantID)
				matchedPlantNames.append(plantName)
				filteredRows.append([plantID, plantName])
				dropdownList.append({
					"value": plantName,
					"label": plantName,
					"ID": plantID
				})
				dropdownList_DS.append({
					"value": plantID,
					"label": plantName
				})
	headers = ["PLANT_ID", "PLANT"]
	filteredDataset = system.dataset.toDataSet(headers, filteredRows)
	return {
		"Plant_IDs": matchedPlantIDs,
		"Plant_Names": matchedPlantNames,
		"Dropdown_List": dropdownList,
		"Dropdown_List_DS": dropdownList_DS,
		"Filtered_Dataset": filteredDataset
	}

def Plant_ID(Business_ID, userRoles):
	return Plant_access(Business_ID, userRoles).get("Plant_IDs", [])

def Plant_Name(Business_ID, userRoles):
	return Plant_access(Business_ID, userRoles).get("Plant_Names", [])

def Plant_DD(Business_ID, userRoles):
	return Plant_access(Business_ID, userRoles).get("Dropdown_List", [])

def Plant_DD_DS(Business_ID, userRoles):
	return Plant_access(Business_ID, userRoles).get("Dropdown_List_DS", [])

def Plant_Dataset(Business_ID, userRoles):
	return Plant_access(Business_ID, userRoles).get("Filtered_Dataset", system.dataset.toDataSet(["PLANT_ID", "PLANT"], []))