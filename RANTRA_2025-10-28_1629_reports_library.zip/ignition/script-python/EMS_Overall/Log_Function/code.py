DB = "EMS_CP"
def EMS_trigger(tag_values, Condition):
    
    if Condition == 'Cell':
        (
            Datetime, Business_code, Business_Name, Plant_Code, Plant_Name,
            Cell_Code, Cell_Name, Machine_ID, Machine_Name, Machine_Code,
            Date, Current_B, Current_R, Current_Y, Current_Total,
            Frequency, kWh, PF, Volt_Avg, Volt_B, Volt_R, Volt_Y, WH, Shift
        ) = tag_values
        
        system.db.runPrepUpdate(
            "INSERT INTO EMS_Main (TimeStamp, Business_ID, Business_Name, Plant_ID, Plant_Name, Cell_ID, Cell_Name, Machine_ID, Machine_Name, Machine_Code, Date, CurrentB, CurrentR, CurrentY, Current_Total, Frequency, KWH, PF, Voltage_Avg, VoltageB, VoltageR, VoltageY, WH, Shift) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            [
                Datetime, Business_code, Business_Name, Plant_Code, Plant_Name,
                Cell_Code, Cell_Name, Machine_ID, Machine_Name, Machine_Code,
                Date, Current_B, Current_R, Current_Y, Current_Total,
                Frequency, kWh, PF, Volt_Avg, Volt_B, Volt_R, Volt_Y, WH, Shift
            ],
            DB
        )

    elif Condition == 'Line':
        (
            Datetime, Business_code, Business_Name, Plant_Code, Plant_Name,
            Line_Code, Line_Name, Machine_ID, Machine_Name, Machine_Code,
            Date, Current_B, Current_R, Current_Y, Current_Total,
            Frequency, kWh, PF, Volt_Avg, Volt_B, Volt_R, Volt_Y, WH, Shift
        ) = tag_values
        
        system.db.runPrepUpdate(
            "INSERT INTO EMS_Main (TimeStamp, Business_ID, Business_Name, Plant_ID, Plant_Name, Line_ID, Line_Name, Machine_ID, Machine_Name, Machine_Code, Date, CurrentB, CurrentR, CurrentY, Current_Total, Frequency, KWH, PF, Voltage_Avg, VoltageB, VoltageR, VoltageY, WH, Shift) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            [
                Datetime, Business_code, Business_Name, Plant_Code, Plant_Name,
                Line_Code, Line_Name, Machine_ID, Machine_Name, Machine_Code,
                Date, Current_B, Current_R, Current_Y, Current_Total,
                Frequency, kWh, PF, Volt_Avg, Volt_B, Volt_R, Volt_Y, WH, Shift
            ],
            DB
        )

    elif Condition == '':
        (
            Datetime, Business_code, Business_Name, Plant_Code, Plant_Name,
            Cell_Code, Cell_Name, Line_Code, Line_Name,
            Machine_ID, Machine_Name, Machine_Code, Date, Current_B, Current_R,
            Current_Y, Current_Total, Frequency, kWh, PF, Volt_Avg, Volt_B, Volt_R, Volt_Y, WH, Shift
        ) = tag_values
        
        system.db.runPrepUpdate(
            "INSERT INTO EMS_Main (TimeStamp, Business_ID, Business_Name, Plant_ID, Plant_Name, Cell_ID, Cell_Name, Line_ID, Line_Name, Machine_ID, Machine_Name, Machine_Code, Date, CurrentB, CurrentR, CurrentY, Current_Total, Frequency, KWH, PF, Voltage_Avg, VoltageB, VoltageR, VoltageY,WH, Shift) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            [
                Datetime, Business_code, Business_Name, Plant_Code, Plant_Name,
                Cell_Code, Cell_Name, Line_Code, Line_Name,
                Machine_ID, Machine_Name, Machine_Code, Date, Current_B, Current_R,
                Current_Y, Current_Total, Frequency, kWh, PF, Volt_Avg, Volt_B, Volt_R, Volt_Y, WH, Shift
            ],
            DB
        )