# emsLogger.py

def log_main_data(machinePath):
	try:
		# Read shared info
		Business = system.tag.read("[default]EMS/LMCI/BG_ID").value
		Plant = system.tag.read("[default]EMS/LMCI/Plant-2/Plant_ID").value
		Cell = "E"
		Line = system.tag.read(machinePath + "/Line_ID").value
		Machine = system.tag.read(machinePath + "/Machine_Id").value
		Date = system.tag.read("[default]EMS/Datetime").value
		Hour = system.tag.read("[default]EMS/Hour").value
		Shift = system.tag.read("[default]EMS/LMCI/Plant-2/Shift").value

		# Electrical values
		VR = int(system.tag.read(machinePath + "/Volt-R").value) * 1.732
		VY = int(system.tag.read(machinePath + "/Volt-Y").value) * 1.732
		VB = int(system.tag.read(machinePath + "/Volt-B").value) * 1.732
		VAvg = int(system.tag.read(machinePath + "/Volt-Avg").value) * 1.732

		CurrentR = system.tag.read(machinePath + "/Current-R").value
		CurrentY = system.tag.read(machinePath + "/Current-Y").value
		CurrentB = system.tag.read(machinePath + "/Current-B").value
		PF = system.tag.read(machinePath + "/PF").value
		Vry = system.tag.read(machinePath + "/V-ry").value
		Vyb = system.tag.read(machinePath + "/V-yb").value
		Vbr = system.tag.read(machinePath + "/V-br").value
		WH = system.tag.read(machinePath + "/WH").value
		KWH = int(system.tag.read(machinePath + "/KWH").value)
		Frequency = system.tag.read(machinePath + "/Frequency").value
		VA = system.tag.read(machinePath + "/VA").value
		ELoad = system.tag.read(machinePath + "/Load").value
		Current_Total = system.tag.read(machinePath + "/CurrentTotal").value
		MD = system.tag.read(machinePath + "/MD").value
		Mod_Date = system.tag.read("[default]EMS/Business/Plant-2/Altered_Date").value

		trigger = int(system.tag.read(machinePath + "/Main_Trigger").value)

		if trigger == 6:
			# Insert to database
			system.db.runPrepUpdate("""
				INSERT INTO EMS_Main (
					Business, Plant, Area, Line, Machine, Date, Hour, Shift,
					VoltageR, VoltageY, VoltageB, CurrentR, CurrentY, CurrentB, PF,
					Vry, Vyb, Vbr, WH, KWH, Frequency, VA, ELoad, Current_Total, Voltage_Avg,
					MD, Mod_Date
				) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
			""", [BG, Plant, Area, Line, Machine, Date, Hour, Shift,
				  VR, VY, VB, CurrentR, CurrentY, CurrentB, PF,
				  Vry, Vyb, Vbr, WH, KWH, Frequency, VA, ELoad, Current_Total, VAvg,
				  MD, Mod_Date], "RDC_EMS")

			# Reset trigger
			system.tag.write(machinePath + "/rt", trigger)
			system.tag.write(machinePath + "/Main_Trigger", 0)
			system.tag.write(machinePath + "/rt", 0)
	except Exception as e:
		system.util.getLogger("EMSLogger").error("Error logging data for: " + machinePath + " - " + str(e))