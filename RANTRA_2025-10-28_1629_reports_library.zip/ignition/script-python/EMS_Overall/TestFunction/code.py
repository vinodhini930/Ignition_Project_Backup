DB = "EMS_CP"

def EMS_trigger(tag_values):
	(
		Datetime, Business_code, Plant_Code,
		Cell_Code, Line_Code, Machine_ID, Machine_Code,
		Date, Shift,
		CurrentB, CurrentR, CurrentY,Current_Total,
		Frequency,kWh,
		PF,Voltage_Avg,
		VoltageB, VoltageR, VoltageY,
		Wh
	) = tag_values
    
	system.db.runPrepUpdate(
		"""
			INSERT INTO EMS_MAIN_DATA
			(
				[timestamp], [business_id], [plant_id], [cell_id], [line_id],
				[machine_id], [machine_code], [date], [shift],
				[currentB], [currentR], [currentY],  [current_total],
				[frequency], [kWh], [pf],[voltage_avg],
				[voltageR], [voltageY], [voltageB],
				[Wh]
			)
			VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
		""",
		[
			Datetime, Business_code, Plant_Code,
			Cell_Code, Line_Code,
			Machine_ID, Machine_Code, Date, Shift,
			CurrentB, CurrentR, CurrentY,Current_Total,
			Frequency, kWh,   PF,Voltage_Avg,
			VoltageB, VoltageR, VoltageY,
			Wh
		],
		DB
	)