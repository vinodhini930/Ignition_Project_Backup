DB = "OEE"
logger = system.util.getLogger("DowntimeLogger")
def MC_Status_Act(tags_to_read):
    #base_path = "[default]Tags/OEE/Enterprise/BG4/Plant2/Line1/Machine1"
    #now = system.date.now()
    tag_values = [tag.value for tag in system.tag.readBlocking(tags_to_read)]

    (
        oee_on, mc_status, mc_status_act, off_tag, dt_oee,
        down_start, down_start_act, BG_Id, BG_Name, Plant, Plant_Name, 
        Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name,
        Operator, Shift, Shift_Hour, Hour, Datetime_Hour,
        Shifttime, Start_Time, Idle_time, Stop_time, Run_time,
        Off_time, Good_Count, Rejection, Part_ID, down_stop, idle_limit,
        Breakdown_ID, idle_Cycle_time, CTH, CTE, CTL, Handling_time_Raw,
        Machining_time_Raw, now
    ) = tag_values

    if oee_on != 1 or mc_status != 1:
        return

    if mc_status_act in [2, 3, 5] and off_tag == 0:
        system.tag.writeBlocking([
            "[.]DT_Start",
            "[.]DT_Start_Act"
        ], [dt_oee, now])

    if mc_status_act == 1:
    	#system.tag.writeBlocking(["[.]DT_Stop"], [now])
    	handle_downtime(now, tag_values)


def handle_downtime(now, tag_values):
    (
        _, _, _, _, _,
        down_start, down_start_act, BG_Id, BG_Name, Plant, Plant_Name, Cell,
        Cell_Name, Line, Line_Name, Machine, Machine_Name,
        Operator, Shift, Shift_Hour, Hour, Datetime_Hour,
        Shifttime, Start_Time, Idle_time, Stop_time, Run_time,
        Off_time, Good_Count, Rejection, Part_ID, down_stop, idle_limit,
        Breakdown_ID,idle_Cycle_time, CTH, CTE, CTL, Handling_time_Raw,
        Machining_time_Raw,now
    ) = tag_values

    total_Count = Good_Count + Rejection
    Stop_time = max(Stop_time, 0)
    #30/07/2025 downTime_act = Idle_time + (Stop_time if Stop_time < 0 else 0)
    downTime_act = Idle_time

    #system.tag.writeBlocking(["[.]DT_Stop"], [down_stop])

    downtime_duration = system.date.secondsBetween(down_start_act, now)
    system.tag.writeBlocking(["[.]Down_Time"], [downtime_duration])

    if downtime_duration <= idle_limit:
        #classify_minor_loss(base_path, BG_Id, Plant, Line, Machine, Shift, Shift_Hour,
                            #Hour, down_start, down_stop, downtime_duration, Breakdown_ID, now)
        classify_minor_loss(BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, 
        					Line_Name, Machine, Machine_Name, Shift, Shift_Hour,
                            Hour, down_start, now, downtime_duration, Breakdown_ID, now)
    else:
        #classify_excess_loss(base_path, BG_Id, Plant, Line, Machine, Shift, Shift_Hour, Hour,
                             #down_start, down_stop, downtime_duration, Good_Count, Rejection, Run_time,
                             #Stop_time, Off_time, Part_ID, Start_Time, now, Operator, Datetime_Hour,
                             #Shifttime, downTime_act, total_Count,Breakdown_ID,idle_Cycle_time, CTH, CTE, 
                             #CTL, Handling_time_Raw,Machining_time_Raw, now)
        classify_excess_loss(BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, 
        					 Line, Line_Name, Machine, Machine_Name, Shift, Shift_Hour, Hour,
                             down_start, now, downtime_duration, Good_Count, Rejection, Run_time,
                             Stop_time, Off_time, Part_ID, Start_Time, now, Operator, Datetime_Hour,
                             Shifttime, downTime_act, total_Count,Breakdown_ID,idle_Cycle_time, CTH, CTE, 
                             CTL, Handling_time_Raw,Machining_time_Raw, now)


def classify_minor_loss(BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, 
						 Line_Name, Machine, Machine_Name, Shift, Shift_Hour,
                         Hour, down_start, down_stop, downtime_duration, Breakdown_ID, date):
    #Breakdown_ID = system.tag.readBlocking([f"{base_path}/Operating_time/Breakdown_ID"])[0].value
    #query = "Select GlobalReason_ID, tpm_id, Local_id, reason_ID from OEE_Downtime_Master where ErrorCode= ?"
    query = "Select GlobalReason_ID, Priority, Priority, ID from OEE_Downtime_Master where ErrorCode= ?"
    result = system.db.runPrepQuery(query, [Breakdown_ID], DB)
    if result and len(result) > 0:
        Global_ID, tpm_id, Local_id, reason_ID = result[0]
    else:
        Global_ID = tpm_id = Local_id = reason_ID = 0

    data = [BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, 
			Line_Name, Machine, Machine_Name, Machine, 
			date, Shift, Hour, down_start, down_stop, Shift_Hour,
            downtime_duration, Breakdown_ID, "Minor Loss", "Minor Loss", Global_ID, tpm_id,
            Local_id, reason_ID, 2,"MC_Status_ML"]
    insert_Downtime(data)
    reset_minor_tags()


def classify_excess_loss(BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, 
						  Line, Line_Name, Machine, Machine_Name, Shift, Shift_Hour, Hour,
                          down_start, down_stop, downtime_duration, Good_Count, Rejection, Run_time,
                          Stop_time, Off_time, Part_ID, Start_Time, End_Time, Operator, Datetime_Hour,
                          Shifttime, downTime_act, total_Count,Breakdown_ID,idle_Cycle_time, CTH, CTE, 
                          CTL, Handling_time_Raw,Machining_time_Raw, date):
	try:
		En_Id = 1 # Testing
		
		result = system.db.runPrepQuery(
		    #"SELECT Global_ID, tpm_id, Local_id, reason_ID FROM Downtime_Reason_Master WHERE Error_code = ?"
		    "Select GlobalReason_ID, Priority, Priority, ID from OEE_Downtime_Master where ErrorCode= ?",
		    [Breakdown_ID], DB)
		if result:
		    Global_id,tpm_id,Local_id,reason_ID = result[0]
		else:
		    Global_id = tpm_id = Local_id = reason_ID = 0
		
		Global_reason = system.db.runScalarPrepQuery(
		    #"SELECT ISNULL(( Select DT_GlobalReason.Gr_Name FROM Downtime_Reason_Master INNER JOIN DT_GlobalReason ON DT_GlobalReason.Gr_Id = Downtime_Reason_Master.Global_Id WHERE Error_code = ?), 'No Record Selected')", [Breakdown_ID], DB)
		    "SELECT ISNULL(( Select GlobalReason_Name FROM OEE_Downtime_Master WHERE ErrorCode = ?), 'No Record Selected')", [Breakdown_ID], DB)
		Breakdown_name = system.db.runScalarPrepQuery(
		    #"SELECT ISNULL((SELECT TOP 1 reason_name FROM Downtime_Reason_Master WHERE Error_code = ?), 'No Record Selected')",[Breakdown_ID], DB)
		    "SELECT ISNULL((SELECT TOP 1 Error FROM OEE_Downtime_Master WHERE ErrorCode = ?), 'No Record Selected')",[Breakdown_ID], DB)
		Breakdown_name_Excess = str(Breakdown_name) + " Excess"
		type = 3
		type1 = 4
		#Reason_Count = system.db.runScalarPrepQuery("select count(*) from Break_master where Shift = ? and Error_code =? and Bg_Id =? and Plant_Id =? and Line_Id =? and Machine_Id = ?",[Shift,Breakdown_ID,BG_Id,Plant,Line,Machine],DB)
		Reason_Count = system.db.runScalarPrepQuery("select count(*) from OEE_Break_Master where Shift_Name = ? and Downtime_ID =? and Business_ID =? and Plant_ID =? and Cell_ID = ? and Line_ID =? and Machine_ID = ?",[Shift,Breakdown_ID,BG_Id,Plant,Cell,Line,Machine],DB)
		#need to change the tag 
		Reason_UD = system.tag.read("[.]Reason_UD").value
		Handling_time = 0 if total_Count==0 else Handling_time_Raw/total_Count
		Maching_Time = 0 if total_Count==0 else Machining_time_Raw/total_Count
		if Reason_Count == 0 and Reason_UD == 1:					
			id_dt = system.db.runScalarPrepQuery("Select Top(1) id from OEE_Downtime where Business_ID = ? and Plant_ID = ? and Cell_ID = ? and Line_ID = ? and Machine_Code = ? and DowntimeType = ? order by ID desc",[BG_Id,Plant,Line,Cell,Machine,type],DB)
			system.db.runPrepUpdate("UPDATE OEE_Downtime SET DowntimeReason_Code = ?,Breakdown_Reason = ?,Global_Reason = ? WHERE ID = ? " , [Breakdown_ID ,Breakdown_name,Global_reason,id_dt],DB)
		
		elif Reason_Count > 0:
		    #parmas3 = {"newValue6":Breakdown_ID,"newValue2":BG_Id,"newValue3":Plant,"Cell":Cell,"newValue4":Line,"newValue5":Machine,"myValueY":Shift,"myValueX":T_stamp}
		    parmas3 = [Breakdown_ID,BG_Id,Plant,Cell,Line,Machine,Shift,T_stamp]
		    DC1 = system.db.runScalarPrepQuery(
				    """
				    SELECT ISNULL((
				        SELECT SUM(Down_Time)
				        FROM OEE_Downtime
				        WHERE DowntimeReason_Code = ?
				          AND Business_ID = ?
				          AND Plant_ID = ?
				          AND Cell_ID = ?
				          AND Line_ID = ?
				          AND Machine_Code = ?
				          AND Shift = ?
				          AND CAST(Start_Time AS DATE) = ?
				    ), 0)
				    """,
				    parmas3,
				    DB
				)
		    Break_std1 = system.db.runScalarPrepQuery("Select isnull((Select Duration from OEE_Break_Master where Downtime_ID = ? and Business_ID =? and Plant_ID=? and Cell_ID = ? and Line_ID =? and Machine_ID = ? and Shift =?),0)",[Breakdown_ID,BG_Id,Plant,Line,Machine,Shift],DB)
		    DC =int(DC1)
		    Break_act = Break_std1 - DC if Break_std1 > DC else 0
		    if downtime_duration > Break_act and Break_act != 0:
		        D_break = Break_act
		        D_act = downtime_duration - Break_act
		        time_ib =system.date.addSeconds(down_start,Break_act)
		        insert_Downtime([BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Machine, date, Shift, Hour, down_start, time_ib, Shift_Hour,D_break,Breakdown_ID ,Breakdown_name,Global_reason,Global_id,tpm_id,Local_id,reason_ID,type1,"MC_Status_BR_RG_1"])
		        insert_Downtime([BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Machine,date,Shift,Hour,time_ib,down_stop, Shift_Hour,D_act,Breakdown_ID ,Breakdown_name_Excess,Global_reason,Global_id,tpm_id,Local_id,reason_ID,type,"MC_Status_DT_RG_1"])
		    if downtime_duration <= Break_act and Break_act != 0:
		        insert_Downtime([BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Machine,date,Shift,Hour,down_start,down_stop,downtime_duration,Breakdown_ID ,Breakdown_name,Global_reason,Global_id,tpm_id,Local_id,reason_ID,type1,"MC_Status_BR_RG_2"])
		    if Break_act == 0:
		        insert_Downtime([BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Machine,date,Shift,Hour,down_start,down_stop,Shift_Hour,downtime_duration,Breakdown_ID ,Breakdown_name_Excess,Global_reason,Global_id,tpm_id,Local_id,reason_ID,type,"MC_Status_DT_RG_3"])
		    Pre_OEE_Data = system.db.runPrepQuery("Select Top(1) ID,Hour,Shift,Start_Time,End_Time,TotalCount,Stoptime,Runtime,IdleCycleTime,Downtime from OEE_OEEData where Business_ID = ? and Plant_ID = ? and Cell_ID = ? and Line_ID = ? and Machine_Code = ? order by id desc",[BG_Id,Plant,Cell,Line,Machine],DB)
		    if Pre_OEE_Data:
		        row = Pre_OEE_Data[0]
		        id, Hour_pre, Shift_pre, Start_pre, end_pre, total_Count_pre, StopTime_pre, run_time_pre, idle_Cycle_time_pre, downTime_pre1 = (row["id"], row["hour"], row["Shift"], row["Sam_Start_Time"], row["Sam_end_Time"], row["total_Count"], row["StopTime"], row["run_time"], row["idle_Cycle_time"], row["downTime"])
		    else:
		        id = Hour_pre = Shift_pre = Start_pre = end_pre = total_Count_pre = StopTime_pre = run_time_pre = idle_Cycle_time_pre = downTime_pre1
		    d_pre = system.date.secondsBetween(Start_pre,end_pre)
		    Operating_Time = Run_time + Stop_time + downtime_duration
		    if Hour_pre != Hour and Shift == Shift_pre and downTime_act < Break_act:
		        StopTime_pre1 = StopTime_pre 
		        downTime_pre = downTime_pre1 - Break_act if downTime_pre1>= Break_act else 0
		        Break_pre = Break_act if downTime_pre1>= Break_act else downTime_pre1
		        downTime = downTime_act if downTime_pre1 >= Break_act else ((downTime_pre1 + downTime_act) - Break_act if (downTime_pre1 + downTime_act) >= Break_act else 0)
		        Break = 0 if downTime_pre1 >= Break_act else (Break_act - Break_pre if (downTime_pre1 + downTime_act) >= Break_act else downTime_act)
		        Operating_Time_pre = run_time_pre + StopTime_pre + downTime_pre
		        break_new = Break_act-downTime_pre1				
		        Update_OEE_DATA([Operating_Time_pre,downTime_pre,Break_pre,StopTime_pre1,id])
		        insert_OEE_DATA([End_Time, BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Machine,Start_Time,End_Time,Stop_time,Run_time,Off_time,Handling_time,Maching_Time,Part_ID,total_Count,Rejection,Good_Count,Operating_Time,Operator,idle_Cycle_time,CTE,CTH,CTL,Shift,Hour,downTime,Break,Datetime_Hour,Shift_Hour,Shifttime,"MC_Status_1"])
		        reset_excess_tags(End_Time) #Add on 15/07/2025
		    else:
		        downTime = float(downTime_act) -float(Break_act) if downTime_act >= Break_act else 0
		        Break = Break_act if downTime_act >= Break_act else downTime_act
		        insert_OEE_DATA([End_Time, BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Machine,Start_Time,End_Time,Stop_time,Run_time,Off_time,Handling_time,Maching_Time,Part_ID,total_Count,Rejection,Good_Count,Operating_Time,Operator,idle_Cycle_time,CTE,CTH,CTL,Shift,Hour,downTime,Break,Datetime_Hour,Shift_Hour,Shifttime,"MC_Status_2"])
		        reset_excess_tags(End_Time) #Add on 15/07/2025
		else:	
		    Break = 0 
		    #StopTime1 = 0 if Stop_time < 0 else Stop_time
		    StopTime1 = Stop_time
		    downTime1 = downTime_act + Stop_time if Stop_time < 0 else downTime_act
		    Operating_Time = Run_time + StopTime1 + downTime1
		    insert_OEE_DATA([End_Time,BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Machine,Start_Time,End_Time,Stop_time,Run_time,Off_time,Handling_time,Maching_Time,Part_ID,total_Count,Rejection,Good_Count,Operating_Time,Operator,idle_Cycle_time,CTE,CTH,CTL,Shift,Hour,downTime_act,Break,Datetime_Hour,Shift_Hour,Shifttime,"MC_Status"])
		    #changw on 17/07/2025 #insert_OEE_DATA([BG_Id,Plant,Line,Machine,Start_Time,End_Time,Stop_time,Run_time,Off_time,Handling_time,Maching_Time,Part_ID,total_Count,Rejection,Good_Count,Operating_Time,Operator,idle_Cycle_time,CTE,CTH,CTL,Shift,Hour,downTime1,Break,Datetime_Hour,Shift_Hour,Shifttime,"MC_Status_3"])
		    insert_Downtime([BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Machine,date,Shift,Hour,down_start,down_stop,Shift_Hour,downtime_duration,Breakdown_ID ,Breakdown_name,Global_reason,Global_id,tpm_id,Local_id,reason_ID,type,"MC_Status_3"])
		    #system.tag.write("[.]../OEE/OEE_Start",End_Time)
		    reset_excess_tags(End_Time)
	
	except Exception as e:
		logger.error("Insert Downtime Error ("+str(Machine)+"): " + str(e))


def reset_minor_tags():
    paths =[
    "[.]Down_Time",
    "[.]../Triggers/DT_Timer", # 24/07/2025
    "[.]../Triggers/HT_Timer",
    "[.]DT_Type",
    "[.]DT_Reason",
    "[.]Minor_Loss"]
    values = [0] * len(paths)
    system.tag.writeBlocking(paths, values)


def reset_excess_tags(end_time):
	reset_Path = 	[
	"[.]../Count/G_Count",
	"[.]../Count/R_Count",
	"[.]Run_Timer",
	"[.]Stop_Timer",
	"[.]Idle_Timer",
	"[.]../Triggers/DT_Timer", #ADD Here for reset
	"[.]../Count/CT_E",
	"[.]../Count/CT_H",
	"[.]../Count/CT_L",
	"[.]HT_Time",
	"[.]MC_Time",
	"[.]Off_Timer",
	"[.]Shift_Time",
	"[.]DT_Reason"
	]
	reset_values = [0] * len(reset_Path)
	reset_Path.append("[.]../OEE/OEE_Start")
	reset_values.append(end_time)
	system.tag.writeBlocking(reset_Path, reset_values)


def insert_Downtime(List):
    system.db.runPrepUpdate("INSERT INTO OEE_Downtime (Business_ID,Business_Name,Plant_ID,Plant_Name,Cell_ID,Cell_Name,Line_ID,Line_Name,Machine_ID,Machine_Name,Machine_Code,TimeStamp,Shift,Hour,Start_time,End_Time,Shift_Hour,Down_Time,DowntimeReason_Code,Breakdown_Reason,Global_Reason,Global_ID,Tpm_ID,Local_ID,Reason_ID,DowntimeType,Trigger_Type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", List,DB)
def insert_OEE_DATA(List):
    system.db.runPrepUpdate("INSERT INTO OEE_OEEData (TimeStamp,Business_ID,Business_Name,Plant_ID,Plant_Name,Cell_ID,Cell_Name,Line_ID,Line_Name,Machine_ID,Machine_Name,Machine_Code,Start_Time,End_Time,Stoptime,Runtime,OffTime,HandlingTime,MachiningTime,Part_ID,TotalCount,RejectionCount,GoodCount,OperatingTime,Operator,IdleCycleTime,CTE,CTH,CTL,Shift,Hour,Downtime,PlannedDowntime,Datetime_Hour,Shift_Hour,ShiftTime,Trigger_Type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",List,DB)
def Update_OEE_DATA(List):
    system.db.runPrepUpdate("UPDATE OEE_OEEData SET OperatingTime = ?,Downtime = ?,PlannedDowntime= ?,Stoptime = ? WHERE ID = ?" ,List,DB)