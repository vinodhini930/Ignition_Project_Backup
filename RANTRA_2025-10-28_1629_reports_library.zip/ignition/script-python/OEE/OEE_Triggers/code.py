DB = "OEE"
def log_oee_data_15Min(tags_to_read):
	tag_values = [tag.value for tag in system.tag.readBlocking(tags_to_read)]
	(
		BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, 
		Machine_Name,Shift, Shift_Hour, date_time, 
		OEE_On, Triger1, Operator, Hour, Datetime_Hour, Part_Id, Start_Time, end_Time,
		StopTime1, run_time, Off_time, Good_Count, Rejection, Reason, downTime1,
		Shifttime, idle_Cycle_time, CTE, CTH, CTL, Handling_total, Maching_total
	) = tag_values
	if OEE_On == 1 and Triger1 == 1:
		# Derived values
		total_Count = Good_Count + Rejection
		StopTime = 0 if StopTime1 < 0 else StopTime1
		#downTime = downTime1 + StopTime1 if StopTime1 < 0 else downTime1
		downTime = downTime1 + StopTime if StopTime1 < 0 else downTime1
		Operating_Time = run_time + StopTime + downTime
		
		# Avoid divide by zero
		Handling_time = float(Handling_total) / total_Count if total_Count > 0 else 0
		Maching_time = float(Maching_total) / total_Count if total_Count > 0 else 0
		Break = 0
		
		# Insert into DB
		insert_params = [
			end_Time, BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, 
			Machine, Machine_Name, Machine, Start_Time, end_Time, StopTime,
			run_time, Off_time, Handling_time, Maching_time, Part_Id, total_Count,
			Rejection, Good_Count, Operating_Time, Operator, idle_Cycle_time,
			CTE, CTH, CTL, Shift, Hour, downTime, Break, Datetime_Hour,
			Shift_Hour,Shifttime,"15Min"
		]
		
		system.db.runPrepUpdate(
		    "INSERT INTO OEE_OEEData (TimeStamp, Business_ID,Business_Name,Plant_ID,Plant_Name,Cell_ID,Cell_Name,Line_ID,Line_Name,Machine_ID,Machine_Name,Machine_Code,Start_Time,End_Time,Stoptime,Runtime,OffTime,HandlingTime,MachiningTime,Part_ID,TotalCount,RejectionCount,GoodCount,OperatingTime,Operator,IdleCycleTime,CTE,CTH,CTL,Shift,Hour,Downtime,PlannedDowntime,Datetime_Hour,Shift_Hour,ShiftTime,Trigger_Type)"
			"values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", 
			insert_params, DB
		)
		#Testing-----------
		En_Id = 1
		# Calculate A, P, Q
		#query_params = {
		#    "myValueX": En_Id, "myValueY": BG_Id, "newValue1": Plant,
		#    "newValue2": Line, "newValue3": Machine, "ST": date_time, "ET": Shift
		#}
		
		Q = 0 #int(system.db.runNamedQuery("RANTRA", "Machine_qual", query_params))
		A = 0 #int(system.db.runNamedQuery("RANTRA", "Machine_Ava", query_params))
		P = 0 #int(system.db.runNamedQuery("RANTRA", "Machine_Per (1)", query_params))
		O = Q * A * P / 10000
		
		result_values = [end_Time, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, A, Q, P, O]
		return result_values
	
def log_oee_data_1Hou(tags_to_read):
    tag_values = [tag.value for tag in system.tag.readBlocking(tags_to_read)]

    (
        OEE_On, MC_Stat, Triger, Triger1,
        BG_Id, BG_Name, Plant, Plant_Name,
        Cell, Cell_Name, Line, Line_Name,
        Machine, Machine_Name,
        Operator, Shift, Shift_Hour, Hour, Datetime_Hour,
        Part_Id, Start_Time, end_Time,
        StopTime1, run_time, Off_time,
        Good_Count, Rejection, Reason, downTime1,
        Shifttime, DT_type, idle_Cycle_time,
        CTE, CTH, CTL, Handling_time_tag, Maching_time_tag
    ) = tag_values

    if Triger1 == 2 and Triger != 6 and OEE_On == 1 and MC_Stat == 1:
        Break = 0
        total_Count = Good_Count + Rejection

        if StopTime1 < 0:
            StopTime = 0
            downTime = downTime1 + StopTime1
        else:
            StopTime = StopTime1
            downTime = downTime1

        Operating_Time = run_time + StopTime + downTime

        if total_Count == 0:
            Handling_time = 0
            Maching_Time = 0
        else:
            Handling_time = int(Handling_time_tag) / total_Count
            Maching_Time = int(Maching_time_tag) / total_Count

        system.db.runPrepUpdate(
		    "INSERT INTO OEE_OEEData (TimeStamp, Business_ID,Business_Name,Plant_ID,Plant_Name,Cell_ID,Cell_Name,Line_ID,Line_Name,Machine_ID,Machine_Name,Machine_Code,Start_Time,End_Time,Stoptime,Runtime,OffTime,HandlingTime,MachiningTime,Part_ID,TotalCount,RejectionCount,GoodCount,OperatingTime,Operator,IdleCycleTime,CTE,CTH,CTL,Shift,Hour,Downtime,PlannedDowntime,Datetime_Hour,Shift_Hour,ShiftTime,Trigger_Type)"
			"values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", 
            [
                end_Time, BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, 
                Machine, Machine_Name, Machine, Start_Time, end_Time, StopTime,
                run_time, Off_time, Handling_time, Maching_Time, Part_Id, total_Count,
                Rejection, Good_Count, Operating_Time, Operator, idle_Cycle_time,
                CTE, CTH, CTL, Shift, Hour, downTime, Break, Datetime_Hour, Shift_Hour,Shifttime,
                "1Hour"
            ], DB
        )


        return [end_Time, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, DT_type]
        
def log_oee_data_Shift(tags_to_read):
    #date = system.date.format(system.date.now(),"yyyy/MM/dd HH:mm:ss")
    tag_values = [tag.value for tag in system.tag.readBlocking(tags_to_read)]
    (
        OEE_On, MC_Stat, Trigger, Trigger1,
        BG_Id, BG_Name, Plant, Plant_Name,
        Cell, Cell_Name, Line, Line_Name,
        Machine, Machine_Name,
        Operator, Shift, Shift_Hour, Shift_Id, Hour, Datetime_Hour,
        Part_Id, Start_Time, end_Time,
        StopTime1, run_time, Off_time,
        Good_Count, Rejection, Reason, downTime1,
        Shifttime, DT_type, idle_Cycle_time,
        CTE, CTH, CTL, Handling_time_tag, Maching_time_tag,
        Down_Start, Down_Start_act, Down_Stop, Idle_limit, 
        Breakdown_ID, currentTimestamp
    ) = tag_values
    date = currentTimestamp
    # Downtime calculation logic #New Condition
    if system.date.getHour24(Down_Start_act) > system.date.getHour24(Shift_Hour) and system.date.getMinute(Down_Start_act) > system.date.getMinute(Shift_Hour) and Shift == "Shift3":
    	Down_Start_act = system.date.addDays(Down_Start_act, -1)
    	secondsBetweenStartAndNow = system.date.secondsBetween(Down_Start_act, currentTimestamp)
    else:
    	secondsBetweenStartAndNow = system.date.secondsBetween(Down_Start_act, currentTimestamp)
    actualDowntime = secondsBetweenStartAndNow
    if (Trigger == 2 or Trigger1 == 1) and OEE_On == 1 and MC_Stat == 1:
        total_Count = Good_Count + Rejection
        if StopTime1 < 0:
            StopTime = 0
            totalDownTimeBeforeBreakEval = downTime1 + StopTime1
        else:
            StopTime = StopTime1
            totalDownTimeBeforeBreakEval = downTime1
        breakReasonExists = system.db.runScalarPrepQuery(
            "select count(*) from OEE_Break_Master where Shift_Name = ? and Downtime_ID =? and Business_ID =? and Plant_ID =? and Cell_ID = ? and Line_ID =? and Machine_ID = ?",
            [Shift, Reason, BG_Id, Plant, Cell, Line, Machine], DB)
        if breakReasonExists > 0:
            #parmas3 = {"newValue6": Reason, "newValue2": BG_Id, "newValue3": Plant,"newValue4": Line, "newValue5": Machine, "myValueY": Shift, "myValueX": end_Time, "Cell":Cell}
            parmas3 = [Reason,BG_Id,Plant,Cell,Line,Machine,Shift,end_Time]
            breakCount = system.db.runScalarPrepQuery(
				    """
				    SELECT ISNULL((
				        SELECT SUM(Down_Time)
				        FROM OEE_Downtime
				        WHERE DowntimeReason_Code = ?
				          AND Business_ID = ?
				          AND Plant_ID = ?
				          AND Cell_ID = ?
				          AND Line_ID = ?
				          AND Machine_Code = ?
				          AND Shift = ?
				          AND CAST(Start_Time AS DATE) = ?
				    ), 0)
				    """,
				    parmas3,
				    DB
				)
            parmas1 =[Reason, BG_Id, Plant, Cell, Line, Machine, Shift]
            breakStandard = system.db.runScalarPrepQuery(
				    """
				    SELECT ISNULL((
				        SELECT Duration
				        FROM OEE_Break_Master
				        WHERE Downtime_ID = ?
				          AND Business_ID = ?
				          AND Plant_ID = ?
				          AND Cell_ID = ?
				          AND Line_ID = ?
				          AND Machine_ID = ?
				          AND Shift = ?
				    ), 0)
				    """,
				    parmas1,
				    "OEE"  # Replace with your database connection name if different
				)
            recordedBreakTime = int(breakCount)
            if breakStandard > recordedBreakTime:
                deductibleBreakDuration = breakStandard - recordedBreakTime
            else:
                deductibleBreakDuration = 0
            if totalDownTimeBeforeBreakEval > deductibleBreakDuration and deductibleBreakDuration != 0:
                downTime = totalDownTimeBeforeBreakEval - deductibleBreakDuration
                Break = deductibleBreakDuration
            elif totalDownTimeBeforeBreakEval <= deductibleBreakDuration and deductibleBreakDuration != 0:
                downTime = 0
                Break = totalDownTimeBeforeBreakEval
            else:
                downTime = totalDownTimeBeforeBreakEval
                Break = 0
        else:
            downTime = totalDownTimeBeforeBreakEval
            Break = 0
        if total_Count == 0:
            Handling_time = 0
            Maching_Time = 0
        else:
            Handling_time = int(Handling_time_tag) / total_Count
            Maching_Time = int(Maching_time_tag) / total_Count
        Operating_Time = run_time + StopTime + downTime
        system.db.runPrepUpdate(
		    "INSERT INTO OEE_OEEData (TimeStamp,Business_ID,Business_Name,Plant_ID,Plant_Name,Cell_ID,Cell_Name,Line_ID,Line_Name,Machine_ID,Machine_Name,Machine_Code,Start_Time,End_Time,Stoptime,Runtime,OffTime,HandlingTime,MachiningTime,Part_ID,TotalCount,RejectionCount,GoodCount,OperatingTime,Operator,IdleCycleTime,CTE,CTH,CTL,Shift,Hour,Downtime,PlannedDowntime,Datetime_Hour,Shift_Hour,ShiftTime,Trigger_Type)"
			"values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", 
            [
                end_Time,BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, 
                Machine, Machine_Name, Machine, Start_Time, end_Time, StopTime,
                run_time, Off_time, Handling_time, Maching_Time, Part_Id, total_Count,
                Rejection, Good_Count, Operating_Time, Operator, idle_Cycle_time,
                CTE, CTH, CTL, Shift, Hour, downTime, Break, Datetime_Hour,
                Shift_Hour, Shifttime, "Shift"
            ], DB
            )
        result = system.db.runPrepQuery("Select GlobalReason_ID, Priority, Priority, ID from OEE_Downtime_Master where ErrorCode= ?",
                                    [Breakdown_ID], DB)
        if result and len(result) > 0:
        	Global_id, tpm_id, Local_id, reason_ID = result[0]
        else:
        	Global_id = tpm_id = Local_id = reason_ID = 0
        Global_reason = system.db.runScalarPrepQuery("SELECT ISNULL((SELECT TOP 1 GlobalReason_Name FROM OEE_Downtime_Master WHERE ErrorCode = ?), 'No Record Selected')", [Global_id], DB )
        if actualDowntime <= Idle_limit:
            Breakdown = Global_reason = "Minor Loss"
            breakdownType = 2
            system.db.runPrepUpdate("INSERT INTO OEE_Downtime (Business_ID,Business_Name,Plant_ID,Plant_Name,Cell_ID,Cell_Name,Line_ID,Line_Name,Machine_ID,Machine_Name,Machine_Code,TimeStamp,Shift,Hour,Start_time,End_Time,Shift_Hour,Down_Time,DowntimeReason_Code,Breakdown_Reason,Global_Reason,Global_ID,Tpm_ID,Local_ID,Reason_ID,DowntimeType,Trigger_Type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Machine,date,Shift,Hour,Down_Start,Down_Stop,Shift_Hour,actualDowntime,Breakdown_ID ,Breakdown,Global_reason,Global_id,tpm_id,Local_id,reason_ID,breakdownType,"Shift"],DB)
        else:
            Breakdown = system.db.runScalarPrepQuery("select(isnull((Select Error from OEE_Downtime_Master where ErrorCode = ?),'Shift End Closer'))",
                                                [Breakdown_ID], DB)
            R = system.db.runScalarPrepQuery("select count(*) from OEE_Break_Master where Shift_Name = ? and Downtime_ID =? and Business_ID =? and Plant_ID =? and Cell_ID = ? and Line_ID =? and Machine_ID = ?",[Shift,Reason,BG_Id,Plant,Cell,Line,Machine],DB)                                        
            breakdownType = 3
            breakdown_excess_Type = 4
            if breakReasonExists > 0:
                if secondsBetweenStartAndNow > deductibleBreakDuration and deductibleBreakDuration != 0:
                    recordedBreakTime = deductibleBreakDuration
                    excessDowntime = secondsBetweenStartAndNow-deductibleBreakDuration
                    breakToExcessTransitionTime =system.date.addSeconds(bb,deductibleBreakDuration)
                    system.db.runPrepUpdate("INSERT INTO OEE_Downtime (Business_ID,Business_Name,Plant_ID,Plant_Name,Cell_ID,Cell_Name,Line_ID,Line_Name,Machine_ID,Machine_Name,Machine_Code,TimeStamp,Shift,Hour,Start_time,End_Time,Shift_Hour,Down_Time,DowntimeReason_Code,Breakdown_Reason,Global_Reason,Global_ID,Tpm_ID,Local_ID,Reason_ID,DowntimeType,Trigger_Type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Machine,date,Shift,Hour,Down_Start,Down_Stop,Shift_Hour,actualDowntime,Breakdown_ID ,Breakdown,Global_reason,Global_id,tpm_id,Local_id,reason_ID,breakdown_excess_Type,"Shift"],DB)
                    system.db.runPrepUpdate("INSERT INTO OEE_Downtime (Business_ID,Business_Name,Plant_ID,Plant_Name,Cell_ID,Cell_Name,Line_ID,Line_Name,Machine_ID,Machine_Name,Machine_Code,TimeStamp,Shift,Hour,Start_time,End_Time,Shift_Hour,Down_Time,DowntimeReason_Code,Breakdown_Reason,Global_Reason,Global_ID,Tpm_ID,Local_ID,Reason_ID,DowntimeType,Trigger_Type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Machine,date,Shift,Hour,Down_Start,Down_Stop,Shift_Hour,actualDowntime,Breakdown_ID ,Breakdown,Global_reason,Global_id,tpm_id,Local_id,reason_ID,breakdownType,"Shift"],DB)
                elif secondsBetweenStartAndNow <= deductibleBreakDuration and deductibleBreakDuration != 0:
                    system.db.runPrepUpdate("INSERT INTO OEE_Downtime (Business_ID,Business_Name,Plant_ID,Plant_Name,Cell_ID,Cell_Name,Line_ID,Line_Name,Machine_ID,Machine_Name,Machine_Code,TimeStamp,Shift,Hour,Start_time,End_Time,Shift_Hour,Down_Time,DowntimeReason_Code,Breakdown_Reason,Global_Reason,Global_ID,Tpm_ID,Local_ID,Reason_ID,DowntimeType,Trigger_Type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Machine,date,Shift,Hour,Down_Start,Down_Stop,Shift_Hour,actualDowntime,Breakdown_ID ,Breakdown,Global_reason,Global_id,tpm_id,Local_id,reason_ID,breakdown_excess_Type,"Shift"],DB)
                else:
                    system.db.runPrepUpdate("INSERT INTO OEE_Downtime (Business_ID,Business_Name,Plant_ID,Plant_Name,Cell_ID,Cell_Name,Line_ID,Line_Name,Machine_ID,Machine_Name,Machine_Code,TimeStamp,Shift,Hour,Start_time,End_Time,Shift_Hour,Down_Time,DowntimeReason_Code,Breakdown_Reason,Global_Reason,Global_ID,Tpm_ID,Local_ID,Reason_ID,DowntimeType,Trigger_Type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Machine,date,Shift,Hour,Down_Start,Down_Stop,Shift_Hour,actualDowntime,Breakdown_ID ,Breakdown,Global_reason,Global_id,tpm_id,Local_id,reason_ID,breakdownType,"Shift"],DB)
            else:
                system.db.runPrepUpdate("INSERT INTO OEE_Downtime (Business_ID,Business_Name,Plant_ID,Plant_Name,Cell_ID,Cell_Name,Line_ID,Line_Name,Machine_ID,Machine_Name,Machine_Code,TimeStamp,Shift,Hour,Start_time,End_Time,Shift_Hour,Down_Time,DowntimeReason_Code,Breakdown_Reason,Global_Reason,Global_ID,Tpm_ID,Local_ID,Reason_ID,DowntimeType,Trigger_Type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Machine,date,Shift,Hour,Down_Start,Down_Stop,Shift_Hour,actualDowntime,Breakdown_ID ,Breakdown,Global_reason,Global_id,tpm_id,Local_id,reason_ID,breakdownType,"Shift"],DB)
    Date_OEE = system.date.format(currentTimestamp,"yy/MM/dd")
    parmasN = {"myValueX":currentTimestamp}#{"myValueX":Date_OEE}
    SP_DATE = system.db.runScalarPrepQuery(
    	"""declare @t as nvarchar(50)
    	set @t = ?
    	select cast (cast(@t as Date ) as varchar) + ' ' +'00:00:00'
    	""",[currentTimestamp],"OEE")
    SP_DATE_1 = system.db.runScalarPrepQuery("Select isnull((Select Top(1) Date_scheduled from OEE_ProductionOffScheduler where Date_scheduled >= ?  and Business_ID =? and Plant_ID=? and Cell_ID = ? and Line_ID =? and Machine_Code = ? order by Date_scheduled asc),0)",[SP_DATE,BG_Id,Plant,Cell,Line,Machine],DB)
    SP_DATE_2,SP_DATE_TIME = system.date.format(SP_DATE_1,"yyyy-MM-dd HH:mm:ss"),system.date.format(SP_DATE_1,"yy/MM/dd")
    Shift_Plan = system.db.runScalarPrepQuery("Select count(*) from OEE_ProductionOffScheduler where Shift_"+str(Shift_Id)+" = 1 and CAST ((Date_Scheduled) AS DATE) =? and Business_ID =? and Plant_ID=? and Cell_ID = ?  and Line_ID =? and Machine_Code = ?",[SP_DATE_2,BG_Id,Plant,Cell,Line,Machine],DB)
    return [Trigger, Trigger1, OEE_On, MC_Stat, actualDowntime, SP_DATE_TIME, Date_OEE, Shift_Plan, end_Time, currentTimestamp, currentTimestamp]
    #return []