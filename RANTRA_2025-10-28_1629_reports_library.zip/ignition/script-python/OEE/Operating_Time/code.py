DB = "OEE"
def DT_Timer(tags_to_read):
	values = [tag.value for tag in system.tag.readBlocking(tags_to_read)]
	
	# Assign values with meaningful names
	mc_status, dt_timer, idle_limit, stop_time, idle_time, minor_loss, bg_id, bg_Name, plant, plant_Name, Cell, Cell_Name, line, Line_Name, machine, Machine_Name, shift, hour = values
	
	# Prepare tag writes
	write_tags = []
	
	if mc_status == 2:
	    if dt_timer < idle_limit:
	        stop_time += 1
	        write_tags += [
	            ["[.]../Operating_Time/Stop_Timer", stop_time],
	            ["[.]../Operating_Time/DT_Type", 2]
	        ]
	    elif dt_timer > idle_limit:
	        idle_time += 1
	        write_tags += [
	            ["[.]../Operating_Time/Idle_Timer", idle_time],
	            ["[.]../Operating_Time/DT_Type", 3]
	        ]
	    #elif dt_timer == idle_limit:
	    elif dt_timer == idle_limit and dt_timer != 0:
	        write_tags.append(["[.]../Operating_Time/Idle_Timer", idle_time])
	
	        # Adjust Stop_time
	        #on 17/07/2025 #new_stop_time = stop_time - idle_limit
	        #on 17/07/2025 #write_tags.append(["[.]../Operating_Time/Stop_Timer", new_stop_time])
	        if stop_time > idle_limit:
	        	new_stop_time = stop_time - idle_limit
	        	write_tags.append(["[.]../Operating_Time/Stop_Timer", new_stop_time])
	        else:
	        	write_tags.append(["[.]../Operating_Time/Stop_Timer", 0])
	        # Fetch latest record in one query
	        row = system.db.runPrepQuery(
	            "SELECT TOP 1 ID, Shift, Hour, Stoptime, Downtime FROM OEE_OEEData "
	            "WHERE Business_ID = ? AND Plant_ID = ? AND Cell_ID = ? AND Line_ID = ? AND Machine_Code = ? ORDER BY id DESC",
	            [bg_id, plant, Cell, line, machine], DB
	        )
	
	        if row:
	            record = row[0]
	            id = record["id"]
	            shift_pre = record["Shift"]
	            hour_pre = record["Hour"]
	            stop_time_pre = record["StopTime"]
	            downtime_pre = record["DownTime"]
	
	            if hour_pre != hour and shift == shift_pre and downtime_pre == 0 and minor_loss == 1:
	                updated_stop_time = stop_time_pre + new_stop_time + 1
	                downtime_new = -new_stop_time
	
	                system.db.runPrepUpdate(
	                    "UPDATE OEE_OEEData SET Downtime = ?, Stoptime = ?,Trigger_Type = ? WHERE ID = ?",
	                    [downtime_new, updated_stop_time, "DT_Timer", id],
	                    DB
	                )
	                write_tags.append(["[.]../Operating_Time/Minor_Loss", 0])
	return write_tags



def updateMachining_Time(tags_to_read):
	tags = [tag.value for tag in system.tag.readBlocking(tags_to_read)]
	if tags[0] != 1:
		return
	b = tags[1]
	a = int(tags[2])
	c = tags[3]
	e = int(tags[4])
	off, run, ht = tags[5], tags[6], tags[7]
	updates = []
	if b == 1:
		updates.append(("[.]../Operating_Time/Off_Timer" , off + 1))
	if a == 1 and b != 1:
		updates.append(("[.]../Operating_Time/Run_Timer", run + 1))
	if a == 2 and b != 1:
		updates.append(("[.]DT_Timer", c + 1))
	if e == 2 and b != 1:
		updates.append(("[.]HT_Timer", ht + 1))
	return updates


def offtime(tags_to_read):
	tag_values = [tag.value for tag in system.tag.readBlocking(tags_to_read)]
	
	# Unpack tag values into meaningful variable names
	(Sft, mc_status, off_tag, T_stamp, BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name,
	 Line, Line_Name, Machine, Machine_Name, Operator, Hour, 
	 Part_Id, down_start, down_start_act, idle_limit, down_stop, date, breakdown_id) = tag_values
	
	# Convert data types if necessary
	mc_status = int(mc_status)
	idle_limit = int(idle_limit)
	tstamp_act = system.date.now()
	
	# Initialize tag writes and queries
	tag_writes = []
	db_queries = []
	
	# Main logic
	if off_tag == 1 and mc_status == 1:
	    tag_writes.extend([
	        ("[.]../Operating_Time/DT_Start", T_stamp),
	        ("[.]../Operating_Time/DT_Start_Act", tstamp_act),
	        ("[.]../Operating_Time/MC_Status_Act", 2)
	    ])
	
	elif off_tag == 0 and mc_status == 1:
	    down_time = system.date.secondsBetween(down_start_act, tstamp_act)
	
	    # Run DB queries to fetch downtime reasons
	    #downtime_reason_query = "SELECT Global_ID, tpm_id, Local_id, reason_ID FROM Downtime_Reason_Master WHERE Error_code = ?"
	    downtime_reason_query ="Select GlobalReason_ID, Priority, Priority, ID from OEE_Downtime_Master where ErrorCode= ?"
	    downtime_reasons = system.db.runPrepQuery(downtime_reason_query, [breakdown_id], DB)
	
	    # Ensure we have a result for downtime reasons
	    if downtime_reasons and len(downtime_reasons) > 0:
	        global_id, tpm_id, local_id, reason_id = downtime_reasons[0]["Global_ID"], downtime_reasons[0]["tpm_id"], downtime_reasons[0]["Local_id"], downtime_reasons[0]["reason_ID"]
	    else:
	        global_id, tpm_id, local_id, reason_id = None, None, None, None
	
	    # Define breakdown and reasons
	    breakdown = "Communication Loss"
	    global_reason = "Communication Loss"
	
	    # Insert downtime data into the database
	    db_queries.append((
	        "INSERT INTO OEE_Downtime (Business_ID,Business_Name,Plant_ID,Plant_Name,Cell_ID,Cell_Name,Line_ID,Line_Name,Machine_ID,Machine_Name,Machine_Code,TimeStamp,Shift,Hour,Start_time,End_Time,Down_Time,DowntimeReason_Code,Breakdown_Reason,Global_Reason,Global_ID,Tpm_ID,Local_ID,Reason_ID,DowntimeType,Trigger_Type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
	        [BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Machine, date, Sft, Hour, down_start, down_stop, down_time, breakdown_id, breakdown, global_reason, global_id, tpm_id, local_id, reason_id, 3,"Off_Tag"],
	        DB
	    ))
	
	    # Add tag writes for reset and update
	    tag_writes.extend([
	        ("[.]../Operating_Time/Down_Time", 0),
	        ("[.]DT_Timer", 0),
	        ("[.]HT_Timer", 0),
	        ("[.]../Operating_Time/DT_Start", T_stamp),
	        #("[.]../Operating_Time/DT_Stop",T_stamp),
	        ("[.]../Operating_Time/DT_Start_Act", tstamp_act),
	        ("[.]../Operating_Time/MC_Status_Act", 1)
	    ])
	    
	for query, params, db in db_queries:
	    system.db.runPrepUpdate(query, params, db)
	return tag_writes
	    
