def PS(tags_to_read):
	# Read multiple tags in a single call
	tags = system.tag.readBlocking(tags_to_read)
	values = [tag.value for tag in tags]
	
	# Assign values to variables for clarity
	OEE_On, T_stamp, Shift_Id, BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, Line, Line_Name, Machine, Machine_Name, Shift1, Shift_ID = values
	Tstamp_act = system.date.now()
	date_oee = system.date.format(T_stamp, "yy/MM/dd")
	
	# Query 1: Shift duration
	shift_duration = system.db.runScalarPrepQuery(
	    """
	    SELECT ISNULL((SELECT TOP(1) Shift_Duration 
	                   FROM Shift_Master
	                   WHERE Business_ID = ? AND Plant_ID = ? AND Shift_Name = ?), 0)
	    """, 
	    [BG_Id, Plant, Shift1], "Master"
	)
	
	En_Id = 1 # for testing
	# Named Query 1: SE
	params_tst = {"newValue2": BG_Id, "newValue3": Plant, "newValue4": Line, 
	              "newValue5": Machine, "newValue6": Shift1, "newValue7": T_stamp,"Cell":Cell}
	#2025-07-28 SE = system.db.runNamedQuery("RANTRA", "TST_V", params_tst)
	SE = system.db.runScalarPrepQuery(
            """
            select count( Shifttime ) from OEE_OEEData where Business_ID = ? and Plant_ID = ? and Cell_ID = ?
                and Line_ID = ? and Machine_Code = ? and Shift = ? and ShiftTime != 0 
                and CAST((Start_Time) AS DATE) = ?
            """,[BG_Id,Plant,Cell,Line,Machine,Shift1,T_stamp],"OEE")
	
	#if SE == 0:
	    #system.tag.write("[default]Tags/OEE/Enterprise/BG4/Plant2/Line1/Machine1/Operating_time/TST", shift_duration)
	
	# Named Query 2: DatePS
	#2025-07-28 date_oee3 = system.db.runNamedQuery("RANTRA", "DatePS", {"myValueX": T_stamp})
	date_oee3 = system.db.runScalarPrepQuery(
    """declare @t as nvarchar(50)
    set @t = ?
    select cast (cast(@t as Date ) as varchar) + ' ' +'00:00:00'
    """,[T_stamp],"OEE")
	
	# Query 2: Date and Shift count
	Date1 = system.db.runScalarPrepQuery(
	    """
	    SELECT ISNULL((SELECT TOP(1) Date_scheduled
	                   FROM OEE_ProductionOffScheduler
	                   WHERE Date_scheduled >= ? AND Business_ID = ? 
	                         AND Plant_ID = ?
	                   ORDER BY Date_scheduled ASC), 0)
	    """, 
	    [date_oee3, BG_Id, Plant], "OEE"
	)
	Date2 = system.date.format(Date1, "yyyy-MM-dd HH:mm:ss")
	Date = system.date.format(Date1, "yy/MM/dd")
	Shift = system.db.runScalarPrepQuery(
	    "SELECT COUNT(*) FROM OEE_ProductionOffScheduler WHERE Shift_"+str(Shift_ID)+" = ? AND CAST(Date_Scheduled AS DATE) = ? AND Business_ID = ? AND Plant_ID = ? AND Cell_ID = ? AND Line_ID = ? AND Machine_Code = ?", 
	    [Shift_Id, Date2, BG_Id, Plant, Cell, Line, Machine], "OEE"
	)
	return [Date,date_oee,Shift,T_stamp,Tstamp_act, SE, shift_duration]
	
	# Conditional logic
	#if Date == date_oee and Shift > 0:
	    #system.tag.writeAll([
	        #"[.]../Count/OEE_On",
	        #"[.]../Operating_time/TST"
	    #], [0, 0])
	#else:
	    #system.tag.writeAll([
	        #"[.]OEE_Start",
	        #"[.]../Operating_time/Down_Start",
	        #"[.]../Operating_time/Down_Start_act",
	        #"[.]../Count/OEE_On"
	    #], [T_stamp, T_stamp, Tstamp_act, 1])