DB = "OEE"
def Rejection_Count(tags_to_read):
	tag_values = [tag.value for tag in system.tag.readBlocking(tags_to_read)]
	
	# Assign values to variables
	(
	    OEE_On, MC_Stat, Reject_Count, Part_Per_Cycle,
	    MT_Actual, HT_Actual, Maching_time, Handling_time, Cycle_time,
	    CTH, CTL, CTE, BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name,
	    Line, Line_Name, Machine, Machine_Name, Shift, Hour,
	    Part_ID, Operator, T_stamp, Rejection_Id, Idle_limit
	) = tag_values
	
	# Ensure script runs only when needed
	#if currentValue.value != previousValue.value and OEE_On == 1 and MC_Stat == 1:
	if OEE_On == 1: # and MC_Stat == 1:
	    # Update reject count
	    Reject_Count = int(Reject_Count)+int(Part_Per_Cycle)
	    CT_Actual = float(MT_Actual + HT_Actual)
	    Handling_time += int(HT_Actual)
	    Maching_time += int(MT_Actual)
	
	    # Update cycle time counts
	    if CT_Actual > Cycle_time:
	        CTH += int(Part_Per_Cycle)
	    elif CT_Actual < Cycle_time:
	        CTL += int(Part_Per_Cycle)
	    else:
	        CTE += int(Part_Per_Cycle)
	
	    # Prepare database updates
	    params_oee = [
	        BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name,
	        Line, Line_Name, Machine, Machine_Name, Hour, Part_Per_Cycle, Operator,
	        Cycle_time, Part_ID, T_stamp, 0, Shift, Part_Per_Cycle, CT_Actual, 
	        Maching_time, Handling_time
	    ]
	    params_quality = [
	        BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name,
	        Line, Line_Name, Machine, Machine_Name, T_stamp, Shift, Hour, 
	        Part_Per_Cycle, Part_Per_Cycle, system.db.runScalarPrepQuery(
	            "SELECT ISNULL((Select RejectionReason_Name from OEE_Rejection_Master Where RejectionReason_ID = ? and Business_ID = ? and Plant_ID = ? and Cell_ID = ? and Line_ID = ? and Machine_Code = ?),'No Rejection Record')", 
	            [Rejection_Id,BG_Id, Plant, Cell, Line, Machine], DB
	        ), Rejection_Id, 
	        system.db.runScalarPrepQuery(
	            "SELECT ISNULL((SELECT RejectionPriority FROM OEE_Rejection_Master WHERE RejectionReason_ID = ?),0)", 
	            [Rejection_Id], DB
	        )
	    ]

	    # Execute database queries
	    system.db.runPrepUpdate(
	        "INSERT INTO OEE_MachineData (Business_ID,Business_Name,Plant_ID,Plant_Name,Cell_ID,Cell_Name,Line_ID,Line_Name,Machine_Code,Machine_Name,Hour,Count,Operator_ID,STD_CycleTime,Part_ID,TimeStamp,Rejection,Shift,CumulativeCount,Actual_CycleTime,Maching_time,Handling_Time) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", 
	        params_oee, DB
	    )
	    system.db.runPrepUpdate(
	        "INSERT INTO OEE_Quality_Data (Business_ID,Business_Name,Plant_ID,Plant_Name,Cell_ID,Cell_Name,Line_ID,Line_Name,Machine_Code,Machine_Name,Time_Stamp,Shift_Name,Hour,Count_ID,Part_Per_Count,Rejection_Name,Rejection_ID,Priority) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", 
	        params_quality, DB
	    )
	    return [Reject_Count, CT_Actual, Handling_time, Maching_time, CTH, CTL, CTE, 0]
	return []
	

def Shot_Count(tags_to_read):
	tag_values = [tag.value for tag in system.tag.readBlocking(tags_to_read)]

	(
	    OEE_On, MC_Running, Part_per_Cycle, Good_Count,
	    MT_Actual, HT_Actual, MT_Tag, HT_Tag, CT_Actual_Tag, CT_Ref,
	    CTH, CTL, CTE, BG_Id, BG_Name, Plant, Plant_Name, Cell,
	    Cell_Name, Line, Line_Name, Machine, Machine_Name, Shift,
	    Hour, Part_ID, Operator, Shot_Count, Cycle_time_Act,
	    T_stamp, Rejection, Idle_limit
	) = tag_values

	if OEE_On == 1: # and MC_Running == 1:
		# Calculate updated values (no writing here)
		Good_Count = int(Good_Count)+int(Part_per_Cycle)
		CT_Actual = float(MT_Actual + HT_Actual)
		HT_Tag += int(HT_Actual)
		MT_Tag += int(MT_Actual)

		if CT_Actual > CT_Ref:
			CTH += int(Part_per_Cycle)
		elif CT_Actual < CT_Ref:
			CTL += int(Part_per_Cycle)
		else:
			CTE += int(Part_per_Cycle)

		# Prepare database insert
		params = [
		    BG_Id, BG_Name, Plant, Plant_Name, Cell, Cell_Name, 
		    Line, Line_Name, Machine, Machine_Name, Hour, Shot_Count,
		    Operator, Cycle_time_Act, Part_ID, T_stamp, Shift,
		    Part_per_Cycle, CT_Actual, MT_Actual, HT_Actual
		]
		system.db.runPrepUpdate("""
		    INSERT INTO OEE_MachineData 
		    (Business_ID,Business_Name,Plant_ID,Plant_Name,Cell_ID,Cell_Name,
		    Line_ID,Line_Name,Machine_Code,Machine_Name,Hour,Count,Operator_ID,
		    STD_CycleTime,Part_ID,TimeStamp,Shift,CumulativeCount,
		    Actual_CycleTime,Maching_time,Handling_Time)
		    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
		""", params, DB)

		# Return updated values for tag writing
		return [Good_Count, CT_Actual, HT_Tag, MT_Tag, CTH, CTL, CTE]

	# If not eligible to run, return empty list
	return []