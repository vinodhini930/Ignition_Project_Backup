import time
#def write_tag(bg_id,bg_name):
	#self.session.custom.BG_ID = bg_id
	#self.session.custom.BG = bg_name

def add_query(table, columns, values, args, db):
    query = "INSERT INTO {} {} VALUES {}".format(table, columns, values)
    system.db.runPrepUpdate(query, args, db)

def modify_query(table, columns, where, args, db):
    query = "UPDATE {} SET {} WHERE {}".format(table, columns, where)
    system.db.runPrepUpdate(query, args, db)

def delete_query(table, where, db):
    query = "DELETE FROM {} WHERE {}".format(table, where)
    system.db.runPrepUpdate(query, db)
	
def open_popup(header, message):
    system.perspective.openPopup("myPopup1", 'PMC/Popup/Notification_Popup', params={'module': header + ' MASTER', 'message': message})
    time.sleep(1)
    system.perspective.closePopup('myPopup1')
    
def close_popup(popup_ID):
	system.perspective.closePopup(popup_ID)

def handle_add(header, table, columns, values, args, id_condition, name_condition, db):
    if id_condition == 0:
        if name_condition == 0:
            add_query(table, columns, values, args, db)
            #write_tag(view_params["BG_ID"], view_params["BG"])
            close_popup('mypopup')
            open_popup(header, "The {} is Added Successfully".format(header))
        else:
            open_popup(header, "The {} Name is already Exist".format(header))
    else:
        open_popup(header, "The {} ID is already Exist".format(header))

def handle_modify(header, table, columns, where, args, add_columns, add_values, add_args, db):
    modify_query(table, columns, where, args, db)
    add_query(table, add_columns, add_values, add_args, db)
    #write_tag(view_params["BG_ID"], view_params["BG"])
    close_popup('mypopup')
    open_popup(header, "The {} is Modified Successfully".format(header))

def handle_delete(header, table, columns, where, args, db):
    modify_query(table, columns, where, args, db)
    #write_tag(view_params["BG_ID"], view_params["BG"])
    close_popup('mypopup')
    open_popup(header, "The {} is Deleted Successfully".format(header))