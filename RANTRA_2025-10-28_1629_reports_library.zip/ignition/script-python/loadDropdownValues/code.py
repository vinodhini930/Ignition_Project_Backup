def setDropdownValuesAndRun(view):
	try:
		root = view.getChild("root")

		business = root.getChild("BusinessContainer").getChild("Business_Dropdown").props.value
		plant = root.getChild("Plant_Container").getChild("Plant_Dropdown").props.value
		cell = root.getChild("Cell").getChild("Cell_Dropdown").props.value
		line = root.getChild("Line_Container").getChild("Line_Dropdown").props.value
		machine = root.getChild("Machine_Container").getChild("Machine_Dropdown").props.value
		shift = root.getChild("Shift_Container").getChild("Shift_Dropdown").custom.Shift_name
		date = root.getChild("Date_Container").getChild("DateTimeInput").props.formattedValue
	except:
		system.util.getLogger("LoadScript").warn("Dropdowns not ready.")
		return

	if None in [business, plant, cell, line, machine, shift, date]:
		system.util.getLogger("LoadScript").warn("Missing one or more required values.")
		return

	# Write to view custom props
	view.custom.selectedBusiness = business
	view.custom.selectedPlant = plant
	view.custom.selectedCell = cell
	view.custom.selectedLine = line
	view.custom.selectedMachine = machine
	view.custom.selectedShift = shift
	view.custom.selectedDate = date

	# Run the checkbox's data loader
	root.getChild("Header").getChild("Checkbox").runDataLoad()