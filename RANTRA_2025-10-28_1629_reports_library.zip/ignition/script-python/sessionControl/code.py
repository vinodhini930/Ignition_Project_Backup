# Project Script: sessionControl

# Global dictionary to track sessions
activeSessions = {}

def registerSession(sessionId, userRoles, userName):
    # Define allowed business roles
    businessRoles = ['RML-BCD', 'RSSL', 'RML-ECD', 'RML-SLD']
    userBusiness = None

    # Find which business the user belongs to
    for role in userRoles:
        if role in businessRoles:
            userBusiness = role
            break

    if userBusiness is None:
        return {"status": "rejected", "message": "No valid business role assigned."}

    # Check if user already has an active session
    for sid, val in activeSessions.items():
        if val['userName'] == userName:
            return {"status": "rejected", "message": "You already have an active session."}

    # Count current sessions for that business
    activeCount = sum(1 for s in activeSessions.values() if s['business'] == userBusiness)
    if activeCount >= 10:
        return {"status": "rejected", "message": f"Only 10 sessions allowed for {userBusiness}."}

    # Register new session
    activeSessions[sessionId] = {
        "userName": userName,
        "business": userBusiness
    }
    return {"status": "ok"}

def unregisterSession(sessionId):
    if sessionId in activeSessions:
        del activeSessions[sessionId]